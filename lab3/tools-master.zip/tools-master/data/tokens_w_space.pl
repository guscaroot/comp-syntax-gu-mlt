bieżący rok
bieżący miesiąc
do spraw
i tak dalej
i tym podobne
Immunoglobina E
kilometr kwadratowy
między innymi
na przykład
na temat
nad poziomem morza
ograniczona odpowiedzialność
pod nazwą
pod tytułem
post scriptum
pod wezwaniem
przed naszą erą
spółka akcyjna
świętej pamięci
tak zwany
to jest
to znaczy
ubiegły rok
w sprawie
wyżej wymieniony
